<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Email</title>
</head>
<body>
    <h1>OTP Verification Code</h1>
    <p>Your OTP verification code is: <?php echo e($otpCode); ?></p>
    <p>Please use this code to complete your registration process.</p>
    <p>If you didn't request this code, you can ignore this email.</p>
    <p>Thank you!</p>
</body>
</html>
<?php /**PATH C:\Users\PLUTON\Desktop\venus-backend\venus\resources\views/emails/otp.blade.php ENDPATH**/ ?>