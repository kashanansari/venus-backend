<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OTP Email</title>
</head>
<body>
    <h1>OTP Verification Code</h1>
    <p>Your OTP verification code is: {{ $otpCode }}</p>
    <p>Please use this code to complete your registration process.</p>
    <p>If you didn't request this code, you can ignore this email.</p>
    <p>Thank you!</p>
</body>
</html>
